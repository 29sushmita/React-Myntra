const ProductReviewobj=[
    {
        review: "The quality and look of the product is very nice and elegant but the piece of blouse is small which doesn't fit for some people of a community. I request seller to make blouse cloth available of 1 metre.",
        vote: "312 people voted."
    },
    {
        review: "The color of the lahanga is as shown in the image, but the quality of the Dress is up to the par with the price. But overall It good.",
        vote: "423 people voted."
    },

    {
        review: "The product is exactly same as in pictures. The quality is great and is full value for money.",
        vote: "365people voted."
    },

    {
        review: "Beautiful lehenga😍, looks exactly as in the picture, provided with an astar inside. The choli cloth is adequate, work done over it is great. The most beautiful part is the dupatta, it is so beautiful, vibrant colour and very good material used. The work done is ultimate benarsi style. I'm drooling over it. I have bought it for my haldi function, yellow and red combination will look great. Thank you Mansvi fashion and Amazon.",
        vote: "212 people voted."
    },

    {
        review: "The quality and look of the product is very nice and elegant but the piece of blouse is small which doesn't fit for some people of a community. I request seller to make blouse cloth available of 1 metre.",
        vote: "365 people voted."
    },

    {
        review: "excellent product, nice lahanga choli, nice color , dupatta length is also very good.. packaging is also good, good purchase... 😍😍 wow product",
        vote: "232 people voted."
    },

];

export default ProductReviewobj;