import * as React from 'react';
import Typography from '@mui/material/Typography';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';

function handleClick(event) {
  event.preventDefault();
  console.info('You clicked a breadcrumb.');
}

const Breadcrumb=()=> {
  return (
    <div role="presentation" onClick={handleClick}>
      <Breadcrumbs aria-label="breadcrumb"  sx={{p:4}}>
        <Link underline="hover" color="inherit" href="/">
          Home
        </Link>
        <Link
          underline="hover"
          color="inherit"
          href="/"
        >
          Men
        </Link>

        <Link
          underline="hover"
          color="inherit"
          href="/"
        >
          Men's clothing
        </Link>

        <Link
          underline="hover"
          color="inherit"
          href="/"
        >
          Shirts
        </Link>

        <Typography color="text.primary">Ramraj Cotton shirts</Typography>
      </Breadcrumbs>
    </div>
  );
}

export default Breadcrumb;
