import * as React from 'react';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';

function srcset(image, size, rows = 1, cols = 1) {
  return {
    src: `${image}?w=${size * cols}&h=${size * rows}&fit=crop&auto=format`,
    srcSet: `${image}?w=${size * cols}&h=${
      size * rows
    }&fit=crop&auto=format&dpr=2 2x`,
  };
}

 const SimgleProductPage=()=> {
  return (
    <>
    <ImageList
      sx={{ width: 670, p:2, pr:4}}
      variant="quilted"
      cols={4}
      rowHeight={121}
    >
      {itemData.map((item) => (
        <ImageListItem key={item.img} cols={item.cols || 1} rows={item.rows || 1}>
          <img
            {...srcset(item.img, 121, item.rows, item.cols)}
            alt={item.title}
            loading="lazy"
          />
        </ImageListItem>
      ))}
    </ImageList>
    </>
  );
}

export default SimgleProductPage;

const itemData = [
  {
    img: 'https://5.imimg.com/data5/QD/FB/NJ/SELLER-21091421/ramraj-cotton-shirt-half-sleeve-500x500.jpg',
    rows: 5,
    cols: 2,
  },
  {
    img: 'https://cdn.shopify.com/s/files/1/0094/0716/8559/products/Untitled-1_0122_DSC04750_2e8e3bba-a53e-42c5-9686-77b856ebc22f_500x.jpg?v=1641464807',
    rows: 4,
    cols: 2,
  },

  {
    img: 'https://cdn.shopify.com/s/files/1/0094/0716/8559/products/Untitled-1_0120_DSC04754_0eb45890-17a1-4bae-840e-6265ee0ba824_500x.jpg?v=1641464858',
    author: '@arwinneil',
    rows: 3,
    cols: 2,
  },
  {
    img: 'https://cdn.shopify.com/s/files/1/0094/0716/8559/products/Untitled-1_0121_DSC04753_6a905642-3531-4c74-a002-e0f544adb44d_500x.jpg?v=1641464808',
    rows: 4,
    cols: 2,
  },
  {
    img: 'https://cdn.shopify.com/s/files/1/0094/0716/8559/products/Untitled-1_0124_DSC04746_75cf0761-b1f5-47d3-a650-72934e375708_500x.jpg?v=1641464858',
    rows: 1.5,
    cols: 2,
  },
  {
    img: 'https://cdn.shopify.com/s/files/1/0094/0716/8559/products/Untitled-1_0123_DSC04749_c48098d8-6caf-40d9-8a2b-4a233d29270e_500x.jpg?v=1641464807',
    rows: 3,
    cols: 2,
  },
  {
    img: 'https://cdn.shopify.com/s/files/1/0094/0716/8559/products/Untitled-1_0123_DSC04749_c48098d8-6caf-40d9-8a2b-4a233d29270e_500x.jpg?v=1641464807',
    rows: 2,
    cols: 2,
  },
];
