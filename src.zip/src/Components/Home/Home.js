import React from 'react';
import  HomeImage  from './HomeImage';
import Products from './Products';

const Home = () => {
  return <>
        <HomeImage />
        <Products />
  </>;
};

export default Home;
