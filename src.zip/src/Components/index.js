
export {default as Home} from "./Home";
export {default as Footer} from "./Footer";
export {default as SingleProduct} from "./SingleProduct";
export {default as WomensProductsPage} from "./WomensProductsPage";
export {default as MansProductsPage} from "./MansProductsPage"
export {default as KidsProductsPage} from "./KidsProductsPage"


